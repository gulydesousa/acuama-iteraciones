UPDATE E SET otineDescripcion=''
FROM otInspeccionesNotificacionEstados AS E WHERE otineCodigo=3